import React, { useEffect, useState } from 'react';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [text, setText] = useState('');
  const [amount, setAmount] = useState('');

  useEffect(() => {
    fetch('http://localhost:5000/api/expenses')
      .then(res => res.json())
      .then(data => setExpenses(data));
  }, []);

  const addExpense = async () => {
    const res = await fetch('http://localhost:5000/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, amount: parseFloat(amount), date: new Date() })
    });
    const data = await res.json();
    setExpenses([...expenses, data]);
    setText('');
    setAmount('');
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="Expense name" />
      <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" />
      <button onClick={addExpense}>Add</button>
      <ul>
        {expenses.map((e, i) => (
          <li key={i}>{e.text}: ${e.amount}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
