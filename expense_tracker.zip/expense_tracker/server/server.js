const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/expensetracker', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const expenseSchema = new mongoose.Schema({
    text: String,
    amount: Number,
    date: Date
});

const Expense = mongoose.model('Expense', expenseSchema);

app.get('/api/expenses', async (req, res) => {
    const expenses = await Expense.find();
    res.json(expenses);
});

app.post('/api/expenses', async (req, res) => {
    const newExpense = new Expense(req.body);
    await newExpense.save();
    res.status(201).json(newExpense);
});

app.listen(5000, () => {
    console.log('Expense Tracker server running on port 5000');
});
